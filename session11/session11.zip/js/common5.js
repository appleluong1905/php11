function changeCongPhuong() {
	document.getElementById("avatar").src =  "cp.jpg";
}
function changeTienDung() {
	document.getElementById("avatar").src =  "td.jpg";
}
function changeXuanTruong() {
	document.getElementById("avatar").src =  "xt.jpg";
}
function changeQuangHai() {
	document.getElementById("avatar").src =  "qh.jpg";
}