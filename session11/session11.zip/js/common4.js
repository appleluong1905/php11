function changeAvatar(name) {
	document.getElementById("avatar").src 
	=  name+ ".jpg";
}