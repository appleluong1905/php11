document.write("Hello PHP11");
document.getElementById("innerContent").innerHTML = "Hello Word";
alert("Hello alert");
console.log("Hello console");
var i = 10;

console.log(i);
alert(i);
i+=20;
 /*
  * This is debug
  * Console
 */
 /*
   This is debug
   Console
 */
console.log(i);
alert(i);
// This x, y, z variable
var x, y, z; 
var x,y,z;
x=5;
x = 5;
var name, old, birthday, city, email;
var name = "Canh", old, birthday, city, 
	email = "apple.luong1905@gmail.com";
console.log(email);



var x = 10, y = 6;
document.write("Gia tri cua x cong y la: ");
document.write(x + y);

